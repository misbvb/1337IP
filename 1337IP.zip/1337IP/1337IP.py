import socket
import os, sys
import requests
g = "\033[0;32m"
w = "\033[0;37m"
r = "\033[0;31m"
b = "\033[0;34m"
#For Windows
os.system('cls')
#For Linux
os.system('clear')


kkz = """======================================================
  __ ____ ____ ______ _____ _____  
 /_ |___ \___ \____  |_   _|  __ \ 
  | | __) |__) |  / /  | | | |__) |
  | ||__ <|__ <  / /   | | |  ___/ 
  | |___) |__) |/ /   _| |_| |     
  |_|____/____//_/   |_____|_|     
                                      
======================================================
[+] Coded By: Kaz0 & MR SHADOW
[+] Twitter: hackieng - 1337_abood
[+] YouTube Channel: https://www.youtube.com/channel/UC9uo64cHzgbOIahnAAbQHYg
======================================================"""
print r,kkz
print(' ')
print(' ')
print(r+'[1] show site ip')
print(r+'[2] show ip of sites list')
print(r+'[3] get the Domains on the same ip')
print(' ')
print(' ')

cc = raw_input(r+"[+] Choose: ")

if cc == '1':
     os.chdir("tools")
     os.system('python2 oneip.py')

elif cc == '2':
      os.chdir("shadow")
      os.system('python2 listip.py')
elif cc == '3':
     os.chdir("tools")
     print(' ')
     rrr = raw_input('[+] put the site or ip: '+w)
     os.system('python2 reverseip.py ' +rrr)
     
    
