import socket
import os

g = "\033[0;32m"
w = "\033[0;37m"
r = "\033[0;31m"
b = "\033[0;34m"


site = raw_input (r+'[+] put the site: '+b)
ffad = socket.gethostbyname(site)
print (r+'[+] the site ip is: '+b+ffad)
